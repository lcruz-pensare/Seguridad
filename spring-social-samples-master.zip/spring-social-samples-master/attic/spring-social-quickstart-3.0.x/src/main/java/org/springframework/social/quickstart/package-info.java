/**
 * Contains @Controllers that demonstrate quick-start application functionality.
 */
package org.springframework.social.quickstart;
