Spring Social Movies
====================
This sample app demonstrates how to create a new service provider implementation along with a new
Java binding to the service's REST API. Specifically, this sample includes a service provider
implementation and API binding for interacting with NetFlix' REST API.

To run, simply import the project into your IDE and deploy to a Servlet 2.5 or > container such as Tomcat 6 or 7.
Access the project at http://localhost:8080/spring-social-movies

Discuss at forum.springsource.org and collaborate with the development team at jira.springframework.org/browse/SOCIAL.
