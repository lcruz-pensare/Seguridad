/**
 * Configures the canvas application.
 */
package org.springframework.social.canvas.config;
