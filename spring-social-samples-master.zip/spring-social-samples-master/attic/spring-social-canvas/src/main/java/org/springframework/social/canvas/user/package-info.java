/**
 * A simple user authentication model supporting the canvas application.
 */
package org.springframework.social.canvas.user;
