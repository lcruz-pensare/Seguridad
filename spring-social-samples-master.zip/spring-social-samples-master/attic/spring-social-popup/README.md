Spring Social Popup
===================
This sample app demonstrates capabilities of the Spring Social project, including:
* Connect to Facebook
* Connect to Twitter
* Handling the connection flow in popup windows

To run, simply import the project into your IDE and deploy to a Servlet 2.5 or > container such as Tomcat 6 or 7.
Access the project at http://localhost:8080/spring-social-popup

Discuss at forum.springsource.org and collaborate with the development team at jira.springframework.org/browse/SOCIAL.
